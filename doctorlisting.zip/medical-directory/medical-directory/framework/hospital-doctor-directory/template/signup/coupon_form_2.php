<div id="coupon-div" style="display: none;">							
		<div class="row form-group">
		<label class="col-md-3 control-label"><?php  esc_html_e('Discount Coupon','medico');?></label>			
			<div class="col-md-9">  <input type="text" class="form-control" name="coupon_name" id="coupon_name" value="" placeholder="Enter Coupon Code">
			</div>
			<div class="coupon-result" id="coupon-result"> 
			</div>										
		</div>		
		<div class="row form-group">
			<label  class="col-md-3 control-label"><?php  esc_html_e('(-) Discount','medico');?></label>
			
			<div class="col-md-9" id="discount">  
			</div>										
		</div>
</div>		
					
						
