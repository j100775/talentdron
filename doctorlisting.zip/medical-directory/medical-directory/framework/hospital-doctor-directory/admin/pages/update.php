<div id="iv_directories-layout">
  <?php include("sidebar.php"); ?>
  <div class="ui grid stackable">
    <div class="row">
      <div class="sixteen wide column">
        <h2 class="ui header">
          <i class="bolt icon purple large"></i>
          <div class="content">
            <?php echo __('Update Products','iv_directories'); ?>
            <div class="sub header"><?php echo __('Synchronize your Products from Amazon with latest data','iv_directories'); ?></div>
          </div>
        </h2>                
      </div>      
    </div>
  </div>
</div><!-- End #iv_directories-layout -->