<div id="iv_directories-layout">
  <?php include("sidebar.php"); ?>
  <div class="ui grid stackable">
    <div class="row">
      <div class="sixteen wide column">
      <h2 class="ui header">
          <i class="dashboard icon purple large"></i>
          <div class="content">
            <?php echo __('iv_directories Affiliate Dashboard','iv_directories'); ?>
            <div class="sub header"><?php echo __('Your Dashboard, Summary, Status, Shortcuts to modules','iv_directories'); ?></div>
          </div>
        </h2>                
      </div>      
    </div>
  </div>
</div><!-- End #iv_directories-layout -->