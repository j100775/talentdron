<?php
update_option('iv_directories_signup-template', 'signup-style-2'); 
update_option('iv_directories_profile-template', 'style-1' ); 
update_option('iv_directories_profile-public', 'style-2' ); 
update_option('iv_directories_post_approved', 'yes' ); 
update_option('_iv_directories_hide_admin_bar', 'yes' ); 


?>
